'''This folder contains various example scripts demonstrating MAVLink functionality.'''
